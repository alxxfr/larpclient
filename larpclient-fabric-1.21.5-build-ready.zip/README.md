# LarpClient (Fabric 1.21.5)

Client-side utility mod with a ClickGUI.

- Open the GUI with **Right Shift** (rebindable in Controls), or via **Mod Menu -> LarpClient -> configure**.
- Modules: Auto Sprint, Fullbright, FPS Counter, Coordinates, Clock. Toggles are saved to `config/larpclient.properties`.

## Build

Option A - locally (needs JDK 21 and Gradle 8.12+):

    gradle wrapper --gradle-version 8.12.1
    ./gradlew build

The jar is in `build/libs/larpclient-fabric-1.21.5-0.3.0.jar` (not the `-sources` one).

Option B - no setup: push this folder to a GitHub repo, open the Actions tab, run "build",
and download the `larpclient-jar` artifact.

## Install

Fabric Loader 0.16.10+, Fabric API for 1.21.5, Java 21. Mod Menu is optional.
