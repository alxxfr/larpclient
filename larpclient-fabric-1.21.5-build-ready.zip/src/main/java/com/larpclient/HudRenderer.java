package com.larpclient;

import com.larpclient.module.Module;
import com.larpclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

public final class HudRenderer {
	private HudRenderer() {}

	public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden) return;

		List<String> lines = new ArrayList<>();
		for (Module m : ModuleManager.all()) {
			if (!m.isEnabled()) continue;
			String t = m.hudText(mc);
			if (t != null) lines.add(t);
		}
		if (lines.isEmpty()) return;

		TextRenderer tr = mc.textRenderer;
		int x = 6, y = 6;
		for (String line : lines) {
			int w = tr.getWidth(line);
			ctx.fill(x - 3, y - 2, x + w + 3, y + 10, 0x90000000);
			ctx.fill(x - 3, y - 2, x - 1, y + 10, 0xFF8B6CFF);
			ctx.drawTextWithShadow(tr, line, x + 2, y, 0xFFFFFFFF);
			y += 14;
		}
	}
}
