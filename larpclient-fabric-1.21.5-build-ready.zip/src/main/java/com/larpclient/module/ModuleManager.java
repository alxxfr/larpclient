package com.larpclient.module;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.client.network.ClientPlayerEntity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

public final class ModuleManager {
	private static final List<Module> MODULES = new ArrayList<>();
	private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("larpclient.properties");

	private ModuleManager() {}

	public static void init() {
		MODULES.clear();

		MODULES.add(new Module("Auto Sprint", "Sprint automatically while moving forward", Module.Category.PLAYER) {
			@Override
			public void onTick(MinecraftClient mc) {
				ClientPlayerEntity p = mc.player;
				if (p == null || mc.currentScreen != null) return;
				if (mc.options.forwardKey.isPressed()
						&& !p.isSneaking()
						&& !p.isUsingItem()
						&& !p.horizontalCollision
						&& p.getHungerManager().getFoodLevel() > 6) {
					p.setSprinting(true);
				}
			}
		});

		MODULES.add(new Module("Fullbright", "See clearly in the dark (client-side night vision)", Module.Category.RENDER) {
			@Override
			public void onTick(MinecraftClient mc) {
				ClientPlayerEntity p = mc.player;
				if (p == null) return;
				StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
				if (cur == null || cur.getDuration() < 600) {
					p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
				}
			}

			@Override
			public void onDisable(MinecraftClient mc) {
				if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
			}
		});

		MODULES.add(new Module("FPS Counter", "Show your frame rate on screen", Module.Category.HUD) {
			@Override
			public String hudText(MinecraftClient mc) {
				return mc.getCurrentFps() + " FPS";
			}
		});

		MODULES.add(new Module("Coordinates", "Show XYZ and facing direction", Module.Category.HUD) {
			@Override
			public String hudText(MinecraftClient mc) {
				ClientPlayerEntity p = mc.player;
				if (p == null) return null;
				String dir = p.getHorizontalFacing().asString();
				dir = dir.substring(0, 1).toUpperCase(Locale.ROOT) + dir.substring(1);
				return String.format(Locale.ROOT, "XYZ %.1f / %.1f / %.1f  %s", p.getX(), p.getY(), p.getZ(), dir);
			}
		});

		MODULES.add(new Module("Clock", "Show your local time", Module.Category.HUD) {
			private final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm:ss");

			@Override
			public String hudText(MinecraftClient mc) {
				return LocalTime.now().format(fmt);
			}
		});

		load();
	}

	public static List<Module> all() {
		return Collections.unmodifiableList(MODULES);
	}

	public static List<Module> byCategory(Module.Category c) {
		List<Module> out = new ArrayList<>();
		for (Module m : MODULES) if (m.getCategory() == c) out.add(m);
		return out;
	}

	public static void tick(MinecraftClient mc) {
		for (Module m : MODULES) {
			if (m.isEnabled()) {
				try {
					m.onTick(mc);
				} catch (Exception e) {
					m.setEnabled(false);
					System.err.println("[LarpClient] Disabled " + m.getName() + " after error: " + e);
				}
			}
		}
	}

	private static String key(Module m) {
		return m.getName().toLowerCase(Locale.ROOT).replace(' ', '_');
	}

	public static void save() {
		Properties props = new Properties();
		for (Module m : MODULES) props.setProperty(key(m), Boolean.toString(m.isEnabled()));
		try (OutputStream out = Files.newOutputStream(CONFIG)) {
			props.store(out, "LarpClient modules");
		} catch (IOException e) {
			System.err.println("[LarpClient] Could not save config: " + e);
		}
	}

	private static void load() {
		if (!Files.exists(CONFIG)) return;
		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(CONFIG)) {
			props.load(in);
		} catch (IOException e) {
			System.err.println("[LarpClient] Could not read config: " + e);
			return;
		}
		for (Module m : MODULES) {
			m.loadState(Boolean.parseBoolean(props.getProperty(key(m), "false")));
		}
	}
}
