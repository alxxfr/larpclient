package com.larpclient.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
	public enum Category {
		PLAYER("Player"), RENDER("Render"), HUD("HUD");

		public final String label;
		Category(String label) { this.label = label; }
	}

	private final String name;
	private final String description;
	private final Category category;
	private boolean enabled;

	/** Animation state (0..1) used by the GUI toggle switch. */
	public float anim;

	protected Module(String name, String description, Category category) {
		this.name = name;
		this.description = description;
		this.category = category;
	}

	public String getName() { return name; }
	public String getDescription() { return description; }
	public Category getCategory() { return category; }
	public boolean isEnabled() { return enabled; }

	public void setEnabled(boolean value) {
		if (enabled == value) return;
		enabled = value;
		if (value) onEnable(MinecraftClient.getInstance());
		else onDisable(MinecraftClient.getInstance());
	}

	public void toggle() {
		setEnabled(!enabled);
		ModuleManager.save();
	}

	/** Used when loading config so the switch doesn't animate from the wrong side. */
	void loadState(boolean value) {
		enabled = value;
		anim = value ? 1f : 0f;
	}

	public void onEnable(MinecraftClient mc) {}
	public void onDisable(MinecraftClient mc) {}
	public void onTick(MinecraftClient mc) {}

	/** Return a line of text to show on the HUD, or null if this module has no HUD output. */
	public String hudText(MinecraftClient mc) { return null; }
}
