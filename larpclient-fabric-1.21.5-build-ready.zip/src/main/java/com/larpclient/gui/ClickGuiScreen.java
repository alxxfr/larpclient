package com.larpclient.gui;

import com.larpclient.LarpClient;
import com.larpclient.module.Module;
import com.larpclient.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ClickGuiScreen extends Screen {
	private static final int W = 340, H = 232;
	private static final int HEADER = 34, TAB_H = 22, ROW_H = 30, FOOTER = 18;

	private static final int ACCENT = 0xFF8B6CFF;
	private static final int BG = 0xF0121218;
	private static final int HEADER_BG = 0xFF181824;
	private static final int ROW_BG = 0xFF181822;
	private static final int ROW_HOVER = 0xFF22222F;
	private static final int OFF = 0xFF3A3A4D;
	private static final int MUTED = 0xFF8A8AA0;

	private final Screen parent;
	private Module.Category category = Module.Category.PLAYER;
	private double scroll;

	public ClickGuiScreen(Screen parent) {
		super(Text.literal("LarpClient"));
		this.parent = parent;
	}

	private int px() { return (width - W) / 2; }
	private int py() { return (height - H) / 2; }
	private int listTop() { return py() + HEADER + TAB_H + 6; }
	private int listBottom() { return py() + H - FOOTER; }
	private List<Module> current() { return ModuleManager.byCategory(category); }
	private double maxScroll() { return Math.max(0, current().size() * ROW_H - (listBottom() - listTop())); }

	private static int lerpColor(int a, int b, float t) {
		int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
		int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
		int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
		return 0xFF000000 | (r << 16) | (g << 8) | bl;
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);

		int x = px(), y = py();

		// panel
		ctx.fill(x - 1, y - 1, x + W + 1, y + H + 1, 0xFF2A2A3D);
		ctx.fill(x, y, x + W, y + H, BG);

		// header
		ctx.fill(x, y, x + W, y + HEADER, HEADER_BG);
		ctx.fill(x, y + HEADER - 2, x + W, y + HEADER, ACCENT);
		ctx.drawTextWithShadow(textRenderer, "Larp", x + 12, y + 13, ACCENT);
		ctx.drawTextWithShadow(textRenderer, "Client", x + 12 + textRenderer.getWidth("Larp"), y + 13, 0xFFFFFFFF);
		String ver = "v" + LarpClient.VERSION;
		ctx.drawTextWithShadow(textRenderer, ver, x + W - 12 - textRenderer.getWidth(ver), y + 13, MUTED);

		// tabs
		Module.Category[] cats = Module.Category.values();
		int tabW = (W - 20) / cats.length;
		int tabY = y + HEADER + 4;
		for (int i = 0; i < cats.length; i++) {
			int tx = x + 10 + i * tabW;
			boolean active = cats[i] == category;
			boolean hover = mouseX >= tx && mouseX < tx + tabW && mouseY >= tabY && mouseY < tabY + TAB_H;
			if (active) ctx.fill(tx, tabY, tx + tabW, tabY + TAB_H, 0xFF1E1E2C);
			else if (hover) ctx.fill(tx, tabY, tx + tabW, tabY + TAB_H, 0xFF171722);
			if (active) ctx.fill(tx, tabY + TAB_H - 2, tx + tabW, tabY + TAB_H, ACCENT);
			ctx.drawCenteredTextWithShadow(textRenderer, cats[i].label, tx + tabW / 2, tabY + 7, active ? 0xFFFFFFFF : MUTED);
		}

		// module list (clipped + scrollable)
		scroll = Math.max(0, Math.min(scroll, maxScroll()));
		int top = listTop(), bottom = listBottom();
		ctx.enableScissor(x + 6, top, x + W - 6, bottom);
		List<Module> mods = current();
		for (int i = 0; i < mods.size(); i++) {
			Module m = mods.get(i);
			int ry = top + i * ROW_H - (int) scroll;
			if (ry + ROW_H < top || ry > bottom) continue;

			boolean hover = mouseX >= x + 8 && mouseX < x + W - 8
					&& mouseY >= Math.max(ry, top) && mouseY < Math.min(ry + ROW_H, bottom);
			ctx.fill(x + 8, ry + 1, x + W - 8, ry + ROW_H - 1, hover ? ROW_HOVER : ROW_BG);
			if (m.isEnabled()) ctx.fill(x + 8, ry + 1, x + 10, ry + ROW_H - 1, ACCENT);

			ctx.drawTextWithShadow(textRenderer, m.getName(), x + 16, ry + 6, 0xFFFFFFFF);
			ctx.drawTextWithShadow(textRenderer, m.getDescription(), x + 16, ry + 17, MUTED);

			// toggle switch
			m.anim += ((m.isEnabled() ? 1f : 0f) - m.anim) * 0.3f;
			int sw = 30, sh = 14;
			int sx = x + W - 8 - 12 - sw, sy = ry + (ROW_H - sh) / 2;
			ctx.fill(sx, sy, sx + sw, sy + sh, lerpColor(OFF, ACCENT, m.anim));
			int kx = sx + 2 + Math.round(m.anim * (sw - sh));
			ctx.fill(kx, sy + 2, kx + sh - 4, sy + sh - 2, 0xFFFFFFFF);
		}
		ctx.disableScissor();

		// footer
		int on = 0;
		for (Module m : ModuleManager.all()) if (m.isEnabled()) on++;
		String foot = on + " enabled   |   Right Shift / Esc to close";
		ctx.drawCenteredTextWithShadow(textRenderer, foot, x + W / 2, y + H - 13, MUTED);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		int x = px(), y = py();

		// tabs
		Module.Category[] cats = Module.Category.values();
		int tabW = (W - 20) / cats.length;
		int tabY = y + HEADER + 4;
		if (mouseY >= tabY && mouseY < tabY + TAB_H) {
			for (int i = 0; i < cats.length; i++) {
				int tx = x + 10 + i * tabW;
				if (mouseX >= tx && mouseX < tx + tabW) {
					category = cats[i];
					scroll = 0;
					return true;
				}
			}
		}

		// modules
		int top = listTop(), bottom = listBottom();
		if (button == 0 && mouseX >= x + 8 && mouseX < x + W - 8 && mouseY >= top && mouseY < bottom) {
			int idx = (int) ((mouseY - top + scroll) / ROW_H);
			List<Module> mods = current();
			if (idx >= 0 && idx < mods.size()) {
				mods.get(idx).toggle();
				return true;
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scroll = Math.max(0, Math.min(maxScroll(), scroll - verticalAmount * 16));
		return true;
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
			close();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public void close() {
		if (client != null) client.setScreen(parent);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
