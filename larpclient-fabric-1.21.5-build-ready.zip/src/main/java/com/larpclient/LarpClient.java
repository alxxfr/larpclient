package com.larpclient;

import com.larpclient.gui.ClickGuiScreen;
import com.larpclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class LarpClient implements ClientModInitializer {
	public static final String MOD_ID = "larpclient";
	public static final String VERSION = "0.3.0";

	private static KeyBinding openGui;

	@Override
	public void onInitializeClient() {
		ModuleManager.init();

		openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.larpclient.open_gui",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				"category.larpclient"));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openGui.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new ClickGuiScreen(null));
				}
			}
			ModuleManager.tick(client);
		});

		HudRenderCallback.EVENT.register(HudRenderer::render);
	}
}
