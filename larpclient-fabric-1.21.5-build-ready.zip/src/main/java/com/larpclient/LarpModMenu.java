package com.larpclient;

import com.larpclient.gui.ClickGuiScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Adds a "configure" button for LarpClient inside Mod Menu. */
public class LarpModMenu implements ModMenuApi {
	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return parent -> new ClickGuiScreen(parent);
	}
}
